# 384_wellplate_automation

## Installation
### Windows
1. Open the powershell and create a new folder by adding: New-Item -Path . -ItemType DragonFlyAutomator
2. Create a python virtual environment by adding: python -m venv DragonFlyAutomator
3. Step into the new folder: cd DragonFlyAutomator
4. Activate the python environment: Scripts\Activate.ps1 
     1. (Ignore this info) Afterwards sys.prefix and sys.exec_prefix point to this
5. Install the software with: pip install https://github.com/Ibrahim-norbert/DragonFlyAutomator/blob/main/dist/DragonFlyAutomator-0.0.1-py3-none-any.whl
6. Then start the application by adding: DragonFlyAutomator

